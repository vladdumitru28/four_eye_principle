#include <iostream>
#include <string.h>
#include <openssl\aes.h>
#include <openssl\bn.h>
#include <openssl\sha.h>
#include <openssl\applink.c>



int main()
{
	unsigned char cypher_text[17];
	unsigned char plain_text[17];
	BIGNUM * cypher = BN_new();
	BN_hex2bn(&cypher,"8E468C11326435BDA16CD0E7FDE4CC23");
	BN_bn2bin(cypher,cypher_text);
	BN_free(cypher);
	char dec_k1[21]="15350283796570290237"; //radacinile de ordin 3 calculate in prealabil
	char dec_k2[21]="8284334661900246245";
	BIGNUM *k1 = BN_new();
	BIGNUM *k2 = BN_new();
	BN_dec2bn(&k1,dec_k1);
	BN_dec2bn(&k2,dec_k2);
	unsigned char bin_k1[9];
	unsigned char bin_k2[9];
	unsigned char bin_k[9];
	BN_bn2bin(k1,bin_k1);
	BN_bn2bin(k2,bin_k2);
	BN_free(k1);
	BN_free(k2);
	for (int i = 0;i<9;i++)
		bin_k[i] = bin_k1[i] ^ bin_k2[i];
	unsigned char k[33];
	SHA256(bin_k,8,k);
	AES_KEY key;
	AES_set_decrypt_key(k, 256, &key);
	AES_decrypt(cypher_text, plain_text, &key);
	plain_text[16] = '\0';
	FILE *f = fopen("plainText.out","w");
	fprintf(f,"%s",plain_text);
	fclose(f);

}